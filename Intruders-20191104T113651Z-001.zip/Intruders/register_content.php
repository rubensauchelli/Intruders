<div class="ui middle aligned center aligned grid" >

  <div class="column">
    
  <form class="ui large form" method="post" action = "registercheck.php" style="padding-top: 50%" id= "registerForm">
      <div class="ui segment" id="loginForm">
      <div class="field">
          <div class="ui left icon input" id="customInput">
          <i class="address book outline icon"></i>
            
            <input type="text" name="firstName" placeholder="First name" required>
          </div>
        </div>
        <div class="field">
          <div class="ui left icon input" id="customInput">
          <i class="address book outline icon"></i>
            
            <input type="text" name="lastName" placeholder="Last name" required>
          </div>
        </div>
        <div class="field">
          <div class="ui left icon input" id="customInput">
            <i class="envelope icon"></i>
            <input type="email" name="email" placeholder="Email" required>
          </div>
        </div>
        
        <div class="field">
          <div class="ui left icon input" id="customInput">
            <i class="user icon"></i>
            <input type="text" name="username" placeholder="Username" required>
          </div>
        </div>
        <div class="field" >
          <div class="ui left icon input" > 
            <i class="lock icon"></i>
            <input type="password" name="password" placeholder="Password" required>
          </div>
        </div>
        <div class="field">
            
          <div class="ui left icon input" id="customInput">
          <i class="key icon"></i>
            <input type="text" name="token" placeholder="Token" required>
          </div>
        </div>
        <button class="ui fluid large black submit button"  id="customButton" type='submit'>Register</button>
      </div>
      <div class="ui message">
      Have an account?<a href="index.php"> Sign In</a>
    </div>
      

    </form>


  </div>
</div>
