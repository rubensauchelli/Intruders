
<?php
//clear the items on the list by unsetting session
unset($_SESSION['itemList']);
//var_dump($_SESSION['itemList']);
echo "<script>window.location = 'list.php'</script>";
?>