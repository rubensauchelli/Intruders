<?php

setcookie("userID", "", time() - 3600);// set cookie past its expiration date for the cookie to be cleared
echo "<script>window.location = 'index.php'</script>";//reload index.php



?>