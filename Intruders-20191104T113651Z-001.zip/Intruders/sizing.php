<?php

$page = "sizing_content.php";
include("template.php");

?>