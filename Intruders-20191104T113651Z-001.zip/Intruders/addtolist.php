<?php
$itemID = $_GET['id'];
//var_dump("hello");
//var_dump($itemID);
//include("db.php");//get our database
    
//SQL used select the footwear

$sql = "SELECT * FROM Item WHERE itemID = '$itemID';";
//var_dump($sql); //used to check the SQL statement used 
$result = query($sql);
confirm($result);


$item= fetch_all($result);//fetching all footwear

//if add to list form was posted
if(isset($_POST["addToList"]))  
 {  
      if(isset($_COOKIE["itemList"]))  
      {  
           $itemListID = array_column($_COOKIE["itemList"], "itemID");  
           
                $count = count($_COOKIE["itemList"]);  
                $item_array = array(  
                     'item_id'               =>     $_GET["id"] 
                     //'itemName'               =>     $_POST["hidden_name"],  
                     
                      
                );  
                $_COOKIE["itemList"][$count] = $itemList;  
            
            
      }  
      else  
      {  
           $itemList = array(  
                'itemID'               =>     $_GET["id"] 
                //'itemName'               =>     $_POST["hidden_name"],  
                
                  
           );  
           $_COOKIE["itemList"][0] = $itemList;  
      } 
      
      //add delete
 } 
 echo '<script>window.location="list.php"</script>'; 
?>