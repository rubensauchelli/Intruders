



    <div class="ui text container" >
      <h1 class="ui inverted header">
        INTRUDERS SOURCING
      </h1>
      <h2 style="color: #9B9B9B">Aquire the most exclusive footwear and garments.</h2>
      <a class="ui inverted button" href="footwear.php">View footwear</a>
    </div>

  </div>

  <div class="ui vertical stripe segment" style='background-color:white'>
    <div class="ui middle aligned stackable grid container">
      <div class="row">
        <div class="eight wide column">
          <h3 class="ui header">Browse our catalogue</h3>
          <p>Browse through our wide range of product and aquire the most exclusive items, get your items as soon as two working days, leave your details with us and we will contact you as soon as your items have been sourced.</p>
          <h3 class="ui header">Authentic items</h3>
          <p>We only provide the most authentic products for our clients, every product you purchase is checked for authenticity by experts in our team.</p>
        </div>
        <div class="six wide right floated column">
          <img src="images/bear.jpg" class="ui large bordered rounded image">
        </div>
      </div>
     
    </div>
  </div>


  <div class="ui vertical stripe quote segment" style="color: white">
    <div class="ui equal width stackable internally celled grid">
      <div class="center aligned row">
        <div class="column">
          <h3>Collect instore</h3>
          <p>Have you been notified your order has been aquired?<br/>Drop by to collect it anytime.</p>
        </div>
        <div class="column">
          <h3>We deliver</h3>
          <p>
              Cant drop by the store? Live overseas?<br/> Dont worry have your order delivered to your doorstep, for an added fee.
          </p>
        </div>
      </div>
    </div>
  </div>

  <div class="ui vertical stripe segment" style='background-color:white'>
  <div class="ui middle aligned stackable grid container">
    <div class="row">
        <div class="six wide left floated column">
              <img src="images/yeezys.jpg" class="ui large bordered rounded image">
        </div>
        
    <div class="eight wide column">
      <h3 class="ui header">Our catalogue is always up to date</h3>
      <p>Week by week, drop by drop, our catalogue is cured with the latest releases to make sure you stay looking fresh with the current heat in the market.</p>
      
      <h4 class="ui horizontal header divider">
        Sizing
      </h4>
      <h3 class="ui header">Dont know your size?</h3>
      <p>Find out exactly what size you are in the UK and your desired item, for more insight ask our knowledgeable staff for a sizing recommendation and feel free to try on the item in a different colorway to find your perfect fit.</p>
      <a class="ui large button">Sizing guide</a>
      </div>
    </div>
    </div>
    
  </div>


 