<?php

//include("db.php"); //link with database
//form values
$firstName = $_POST["firstName"];
$lastName = $_POST["lastName"];      
$address1 = $_POST["address"];   
$address2 = $_POST["address2"]; 
$postcode = $_POST["postcode"]; 
$country = $_POST["country"]; 
$city = $_POST["city"];   
$phoneNumber = $_POST["phoneNumber"];   


//sql statement to insert input by user into database
$sql1 = "INSERT INTO Customer(firstName,lastName,streetAddress,aptNo,postCode,country,city,phoneNumber)
Values( '$firstName', '$lastName','$address1','$address2','$postcode','$country','$city','$phoneNumber');";
        //var_dump($sql); //used to check the SQL statement used 
//executing the statement  
query($sql1);

//var_dump($sql1);



$itemList =$_SESSION['itemList'];
$listSize = count($itemList);
//var_dump('enter if');
//var_dump($listSize);
$date = date('Y-m-d'); // setting of the format of the date will be recorded as
//var_dump($date);

//used to store all items
for($i=0;$i<$listSize;$i++){

    


    $itemID = $itemList[$i];
    $size = $_POST["$i"];

    $sql2 = "SELECT customerID   FROM Customer WHERE phoneNumber = '$phoneNumber';";
    //var_dump($sql); //used to check the SQL statement used 
    $result = query($sql2);
    confirm($result);
    $id = fetch_array($result);//fetching all footwear
    $customerIDstr = $id['customerID'];

    $customerID = (int)$customerIDstr;
  //  var_dump($customerID);
    //var_dump($itemList[$i]);
    //sql statement to insert input by user into database
    $insert = "INSERT INTO Orders(customerID,itemID,size,orderDate)
    Values( $customerID,'$itemID','$size','$date');";
            //var_dump($sql); //used to check the SQL statement used 
    //executing the statement 
  //  var_dump($insert); 
   // $database->exec($insert);]
   query($insert);
    

    

}

//unset($db);//clean up our resources 
//clear cart after order has been stored
unset($_SESSION['itemList']);
//redirect home
echo "<script>window.location = 'homepage.php'</script>";



?>