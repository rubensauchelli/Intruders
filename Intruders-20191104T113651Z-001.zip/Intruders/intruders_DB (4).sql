-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 20, 2019 at 01:12 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `intruders_DB`
--

-- --------------------------------------------------------

--
-- Table structure for table `Clothing`
--

CREATE TABLE `Clothing` (
  `clothingID` int(11) NOT NULL,
  `itemID` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Clothing`
--

INSERT INTO `Clothing` (`clothingID`, `itemID`) VALUES
(12, 'Sp-Blcfw18Agy'),
(14, 'Sp-Blcfw18Bk'),
(8, 'Sp-Blcfw18Br'),
(7, 'Sp-Blcfw18Dgn|'),
(6, 'Sp-Blcfw18Fpk'),
(4, 'Sp-Blcfw18M'),
(10, 'Sp-Blcfw18Nt'),
(9, 'Sp-Blcfw18Nv'),
(3, 'Sp-Blcfw18Ru'),
(2, 'Sp-Blhsbkfw17'),
(5, 'Sp-Cdgsbltbk'),
(11, 'Sp-Cdgssblhsbk'),
(1, 'Sp-Cdgssblhswt'),
(13, 'Sp-Cdgssbltbk'),
(15, 'Sp-Cdgssbltwt');

-- --------------------------------------------------------

--
-- Table structure for table `Customer`
--

CREATE TABLE `Customer` (
  `customerID` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `streetAddress` varchar(255) DEFAULT NULL,
  `aptNo` varchar(25) DEFAULT NULL,
  `postCode` varchar(30) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `phoneNumber` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Customer`
--

INSERT INTO `Customer` (`customerID`, `firstName`, `lastName`, `streetAddress`, `aptNo`, `postCode`, `country`, `city`, `phoneNumber`) VALUES
(1, 'Ruben', 'Sauchelli', '408 Chapelier House, Eastfields Avenue', 'Eastfields Avenue', 'SW18 1LR', 'Albania', 'London', '7437479872'),
(2, 'Ruben', 'Sauchelli', '408 Chapelier House, Eastfields Avenue', 'Eastfields Avenue', 'SW18 1LR', 'Albania', 'London', '7437479872'),
(3, 'Ruben', 'Sauchelli', '408 Chapelier House, Eastfields Avenue', 'Eastfields Avenue', 'SW18 1LR', 'American Samoa', 'London', '7437479872'),
(4, 'Ruben', 'Sauchelli', '408 Chapelier House, Eastfields Avenue', 'Eastfields Avenue', 'SW18 1LR', 'Bouvet Island', 'London', '7437479872'),
(5, 'Ruben', 'Sauchelli', '408 Chapelier House, Eastfields Avenue', 'Eastfields Avenue', 'SW18 1LR', 'Algeria', 'London', '07437479872'),
(6, 'Ruben', 'Sauchelli', '408 Chapelier House, Eastfields Avenue', 'Eastfields Avenue', 'SW18 1LR', 'Algeria', 'London', '07437479872'),
(7, 'Ruben', 'Sauchelli', '408 Chapelier House, Eastfields Avenue', 'Eastfields Avenue', 'SW18 1LR', 'Albania', 'London', '7437479872'),
(8, 'Ruben', 'Sauchelli', '408 Chapelier House', 'Eastfields Avenue', 'SW18 1LR', 'England', 'London', '07437479872'),
(9, 'Ruben', 'Sauchelli', '408 Chapelier House, Eastfields Avenue', 'Eastfields Avenue', 'SW18 1LR', 'Albania', 'London', '7437479872'),
(10, 'Ruben', 'Sauchelli', '408 Chapelier House, Eastfields Avenue', 'Eastfields Avenue', 'SW18 1LR', 'Aland Islands', 'London', '7437479872'),
(11, 'Ruben', 'Sauchelli', '408 Chapelier House', 'Eastfields Avenue', 'SW18 1LR', 'Albania', 'London', '07437479872'),
(12, 'Ruben', 'Sauchelli', '408 Chapelier House', 'Eastfields Avenue', 'SW18 1LR', 'American Samoa', 'London', '07437479872'),
(13, 'Ruben', 'Sauchelli', '408 Chapelier House, Eastfields Avenue', 'Eastfields Avenue', 'SW18 1LR', 'Algeria', 'London', '7437479872');

-- --------------------------------------------------------

--
-- Table structure for table `Footwear`
--

CREATE TABLE `Footwear` (
  `footwearID` int(11) NOT NULL,
  `itemID` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Footwear`
--

INSERT INTO `Footwear` (`footwearID`, `itemID`) VALUES
(18, 'B37571'),
(10, 'B37572'),
(9, 'B75571'),
(19, 'BB1826'),
(8, 'BY1604'),
(24, 'BY9612'),
(7, 'CP9366'),
(23, 'CP9652'),
(12, 'CP9654'),
(20, 'DB2908'),
(22, 'DB2966'),
(16, 'EE7287'),
(15, 'EE9614'),
(21, 'EF2829'),
(2, 'EF2905'),
(6, 'EF2905'),
(14, 'EG7487'),
(3, 'EG7490'),
(5, 'EG7491'),
(4, 'EG7492'),
(1, 'EG7597'),
(17, 'F36640'),
(13, 'F36980'),
(11, 'F99710');

-- --------------------------------------------------------

--
-- Table structure for table `Item`
--

CREATE TABLE `Item` (
  `itemID` varchar(255) NOT NULL,
  `itemName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Item`
--

INSERT INTO `Item` (`itemID`, `itemName`) VALUES
('DB2908', 'Adidas Yeezy 500 Blush'),
('EE7287', 'Adidas Yeezy 500 Salt'),
('DB2966', 'Adidas Yeezy 500 Super Moon Yellow'),
('F36640', 'Adidas Yeezy 500 Utility Black'),
('EE9614', 'Adidas Yeezy 700 Mauve'),
('EF2829', 'Adidas Yeezy 700 V2 Static'),
('BB1826', 'Adidas Yeezy Boost 350 V2 Beluga'),
('CP9366', 'Adidas Yeezy Boost 350 V2 Beluga 2.0'),
('CP9652', 'Adidas Yeezy Boost 350 V2 Black Red'),
('B37571', 'Adidas Yeezy Boost 350 V2 Blue Tint'),
('F36980', 'Adidas Yeezy Boost 350 V2 Butter'),
('EG7490', 'Adidas Yeezy Boost 350 V2 Clay'),
('BY9612', 'Adidas Yeezy Boost 350 V2 Core Black Red'),
('BY1604', 'Adidas Yeezy Boost 350 V2 Cream/Triple White'),
('EG7491', 'Adidas Yeezy Boost 350 V2 Hyperspace'),
('B37572', 'Adidas Yeezy Boost 350 V2 Semi Frozen Yellow\r\n'),
('F99710', 'Adidas Yeezy Boost 350 V2 Sesame'),
('EF2905', 'Adidas Yeezy Boost 350 V2 Static'),
('EG7492', 'Adidas Yeezy Boost 350 V2 Trfrm'),
('CP9654', 'Adidas Yeezy Boost 350 V2 Zebra'),
('EG7597', 'Adidas Yeezy Boost 700 Inertia'),
('EG7487', 'Adidas Yeezy Boost 700 Salt'),
('EG6860', 'Adidas Yeezy Boost 700 V2 Geode'),
('B75571', 'Adidas Yeezy Boost 700 Wave Runner Solid Grey'),
('Sp-Blcfw18Agy', 'Supreme Box Logo Crewneck (FW18) Ash Grey'),
('Sp-Blcfw18Bk', 'Supreme Box Logo Crewneck (FW18) Black'),
('Sp-Blcfw18Br', 'Supreme Box Logo Crewneck (FW18) Bright Royal\r\n'),
('Sp-Blcfw18Dgn|', 'Supreme Box Logo Crewneck (FW18) Dark Green\r\n'),
('Sp-Blcfw18Fpk', 'Supreme Box Logo Crewneck (FW18) Fluorescent Pink\r\n'),
('Sp-Blcfw18M', 'Supreme Box Logo Crewneck (FW18) Mustard\r\n'),
('Sp-Blcfw18Nt', 'Supreme Box Logo Crewneck (FW18) Natural\r\n'),
('Sp-Blcfw18Nv', 'Supreme Box Logo Crewneck (FW18) Navy\r\n'),
('Sp-Blcfw18Ru', 'Supreme Box Logo Crewneck (FW18) Rust\r\n'),
('Sp-Blhsbkfw17', 'Supreme Box Logo Hooded Sweatshirt (FW17) Black\r\n'),
('Sp-Cdgsbltbk', 'Supreme Comme Des Garcons SHIRT Box Logo Tee Black\r\n'),
('Sp-Cdgssblhsbk', 'Supreme Comme des Garcons SHIRT Split Box Logo Hooded Sweatshirt Black\r\n'),
('Sp-Cdgssblhswt', 'Supreme Comme des Garcons SHIRT Split Box Logo Hooded Sweatshirt White\r\n'),
('Sp-Cdgssbltbk', 'Supreme Comme des Garcons SHIRT Split Box Logo Tee Black'),
('Sp-Cdgssbltwt', 'Supreme Comme des Garcons SHIRT Split Box Logo Tee White');

-- --------------------------------------------------------

--
-- Table structure for table `Orders`
--

CREATE TABLE `Orders` (
  `orderID` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `streetAddress` varchar(255) NOT NULL,
  `aptNo` varchar(255) NOT NULL,
  `postCode` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `phoneNumber` varchar(255) NOT NULL,
  `orderDate` varchar(255) NOT NULL,
  `orderTime` varchar(255) NOT NULL,
  `total` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `PendingOrder`
--

CREATE TABLE `PendingOrder` (
  `pendingOrderID` int(11) NOT NULL,
  `orderID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ProcessedOrder`
--

CREATE TABLE `ProcessedOrder` (
  `processedOrderID` int(11) NOT NULL,
  `orderID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Purchase`
--

CREATE TABLE `Purchase` (
  `purchaseID` int(255) NOT NULL,
  `orderID` int(255) NOT NULL,
  `itemID` varchar(255) NOT NULL,
  `itemName` varchar(255) NOT NULL,
  `itemPrice` float NOT NULL,
  `itemSize` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Token`
--

CREATE TABLE `Token` (
  `tokenValue` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Token`
--

INSERT INTO `Token` (`tokenValue`) VALUES
('token3');

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE `User` (
  `userID` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`userID`, `username`, `password`, `firstName`, `lastName`, `email`) VALUES
(1, 'ruben99', '5b722b307fce6c944905d132691d5e4a2214b7fe92b738920eb3fce3a90420a19511c3010a0e7712b054daef5b57bad59ecbd93b3280f210578f547f4aed4d25', NULL, NULL, NULL),
(2, 'ruben', '5b722b307fce6c944905d132691d5e4a2214b7fe92b738920eb3fce3a90420a19511c3010a0e7712b054daef5b57bad59ecbd93b3280f210578f547f4aed4d25', NULL, NULL, NULL),
(3, 'user', '5b722b307fce6c944905d132691d5e4a2214b7fe92b738920eb3fce3a90420a19511c3010a0e7712b054daef5b57bad59ecbd93b3280f210578f547f4aed4d25', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Clothing`
--
ALTER TABLE `Clothing`
  ADD PRIMARY KEY (`clothingID`),
  ADD KEY `itemID` (`itemID`);

--
-- Indexes for table `Customer`
--
ALTER TABLE `Customer`
  ADD PRIMARY KEY (`customerID`);

--
-- Indexes for table `Footwear`
--
ALTER TABLE `Footwear`
  ADD PRIMARY KEY (`footwearID`),
  ADD KEY `itemID` (`itemID`);

--
-- Indexes for table `Item`
--
ALTER TABLE `Item`
  ADD PRIMARY KEY (`itemID`),
  ADD UNIQUE KEY `itemName` (`itemName`);

--
-- Indexes for table `Orders`
--
ALTER TABLE `Orders`
  ADD PRIMARY KEY (`orderID`);

--
-- Indexes for table `PendingOrder`
--
ALTER TABLE `PendingOrder`
  ADD PRIMARY KEY (`pendingOrderID`),
  ADD KEY `orderID` (`orderID`);

--
-- Indexes for table `ProcessedOrder`
--
ALTER TABLE `ProcessedOrder`
  ADD PRIMARY KEY (`processedOrderID`),
  ADD KEY `orderID` (`orderID`);

--
-- Indexes for table `Purchase`
--
ALTER TABLE `Purchase`
  ADD PRIMARY KEY (`purchaseID`),
  ADD KEY `orderID` (`orderID`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Clothing`
--
ALTER TABLE `Clothing`
  MODIFY `clothingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `Customer`
--
ALTER TABLE `Customer`
  MODIFY `customerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `Footwear`
--
ALTER TABLE `Footwear`
  MODIFY `footwearID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `Orders`
--
ALTER TABLE `Orders`
  MODIFY `orderID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `User`
--
ALTER TABLE `User`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
