<?php
  
  $page = "logincheck_content.php";
  include("pretemplate.php");

?>