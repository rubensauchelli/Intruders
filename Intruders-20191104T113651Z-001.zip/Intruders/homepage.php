<?php

$page = "homepage_content.php";
include("template.php");

?>