<?php

include("db.php"); //link with database


//creating variables that will be the credentials entered

$username = $_POST["username"];
$password = $_POST["password"];
$email = $_POST["email"];
$firstName = $_POST["firstName"];
$lastName = $_POST["lastName"];
$token = $_POST["token"];
if (isset($_POST["username"])){
 // check the username and password
 $sql = "SELECT * FROM Token WHERE tokenValue = '$token' ";
 //var_dump($sql);
 $result = query($sql);
 confirm($result);
 $tokenResult = fetch_array($result);
 //var_dump($token);
 if (!empty($tokenResult)) {
        $hash = hash('sha512', $password);
        //var_dump($hash);
        //sql statement to insert input by user into database
        $insert = "Insert Into User(username,password)
        Values( '$username', '$hash');";
        $delete = "DELETE FROM Token WHERE tokenValue='$token';
        ";
        //var_dump($delete);
    //executing the statement        
    query($insert);
    //var_dump($insert);
     //executing the statement  
     //var_dump($delete);      
    query($delete);
     echo "<script>window.location = 'index.php'</script>";
 }
 else {
    // incorrect login, show the form again with a prompt
    
    echo '<div class="ui red message">The token was non-existant, please try again.</div>';
    

    include("register.php");
  } 
} else {
  // this will show the form if there hasn't been a user login attempt
  include("register.php");
}
// clean up our resources
//unset($db);
 



?>
 <script>
 $("#loginForm").validate();//add validation
</script>

