<html>
<head>
  <!-- Standard Meta -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

  <!-- Site Properties -->
  <title>Homepage - Semantic</title>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
    <!--<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/components/visibility.min.js">-->
    
    <link rel="stylesheet" href="general.css">
    <script
			  src="https://code.jquery.com/jquery-3.3.1.min.js"
			  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
        crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js" integrity="sha256-t8GepnyPmw9t+foMh3mKNvcorqNHamSKtKRxxpUEgFI=" crossorigin="anonymous"></script>
    
    


  
    
  
  
  <script >
  $(document)
    .ready(function() {

      // fix menu when passed
      $('.masthead')
        .visibility({
          once: false,
          onBottomPassed: function() {
            $('.fixed.menu').transition('fade in');
          },
          onBottomPassedReverse: function() {
            $('.fixed.menu').transition('fade out');
          }
        })
      ;

      // create sidebar and attach to menu open
      $('.ui.sidebar')
        .sidebar('attach events', '.toc.item')
      ;

    })
  ;
  </script>
</head>
<body>
<!-- link stylesheet-->
<!--<link rel="stylesheet" href="homepage.css">-->

<!-- Following Menu -->
<div class="ui large top fixed hidden menu">
  <div class="ui container">
    <a class="active item">Home</a>
    <a class="item">Featured</a>
    <a class="item">Footwear</a>
    <a class="item">Clothing</a>
    <a class="item">Sizing</a>


    <div class="right menu">
      <div class="item">
        <a class="ui button">Log in</a>
      </div>
      <div class="item">
      <a class="ui inverted red button" href="logout.php" role="button">Log out</a>
      </div>
    </div>
  </div>
</div>

<!-- Sidebar Menu -->
<div class="ui vertical inverted sidebar menu">
  <a class="active item">Home</a>
  <a class="item">Featured</a>
  <a class="item">Footwear</a>
  <a class="item">Clothing</a>
  <a class="item">Sizing</a>
  <a class="item">Login</a>
  <a class="item" href="logout.php">Log out</a>
</div>




<!-- Page Contents -->
<div class="pusher">
  <div class="ui vertical masthead center aligned segment" style='opacity: 1.0'>

    <div class="ui container " >
      <div class="ui large secondary inverted pointing menu">
        <a class="toc item">
          <i class="sidebar icon"></i>
        </a>
        <a class="active item">Home</a>
        <a class="item">Featured</a>
        <a class="item" href="footwear.php">Footwear</a>
          <a class="item">Clothing</a>
          <a class="item">Sizing</a>
        <div class="right item">
          <a class="ui inverted button">Log in</a>
          <a class="ui inverted red basic button" href="logout.php" role="button">Log out</a>
        </div>
      </div>
    </div>
    <!-- include the php on separate page-->
    <?php
    include("db.php");//get our database
        //SQL used select the notices
        $sql = "SELECT * FROM Item";
        //var_dump($sql); //used to check the SQL statement used 
        $result =query($sql);
        confirm($result);
        $items = fetch_all($result);//fetching all notices
        
        
        

        foreach ($items as $item){ // populates table on the website for every notice on the database
            echo'<div class="ui six doubling cards">';
            //echo '<div class="column">'; 
            echo '<div class="card">'; 
            echo '<div class="image">';
            echo '<img src="';
            echo $item['displayImage'];
            echo '">';
            echo '</div>';
            //echo '</div>';
            echo '</div>';
            echo '</div>';
           

        }
        //unset($db);//clean up our resources 
        ?>
    <!-- END-->


  <div class="ui vertical footer segment">
    <div class="ui container">
      <div class="ui stackable inverted divided equal height stackable grid">
        <div class="three wide column">
          <h4 class="ui inverted header">About</h4>
          <div class="ui inverted link list">
            <a href="#" class="item">Sitemap</a>
            <a href="#" class="item">Contact Us</a>
            <a href="#" class="item">Religious Ceremonies</a>
            <a href="#" class="item">Gazebo Plans</a>
          </div>
        </div>
        <div class="three wide column">
          <h4 class="ui inverted header">Services</h4>
          <div class="ui inverted link list">
            <a href="#" class="item">Banana Pre-Order</a>
            <a href="#" class="item">DNA FAQ</a>
            <a href="#" class="item">How To Access</a>
            <a href="#" class="item">Favorite X-Men</a>
          </div>
        </div>
        <div class="seven wide column">
          <h4 class="ui inverted header">Footer Header</h4>
          <p style= "color: grey">Extra space for a call to action inside the footer that could help re-engage users.</p>
        </div>
      </div>
    </div>
  </div>
</div>

</body>

</html>