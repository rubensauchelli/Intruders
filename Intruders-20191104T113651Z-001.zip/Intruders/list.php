<?php

$page = "list_content.php";
include("template.php");

?>