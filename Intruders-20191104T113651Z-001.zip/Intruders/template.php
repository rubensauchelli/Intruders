<?php
//start session
session_start();
//var_dump('session started');

//echo 'Current PHP version: ' . phpversion();
if(!isset($_COOKIE["userID"])){
  
  echo "<script>window.location = 'index.php'</script>";
    exit();
}



?>
<html>
<head>
  <!-- Standard Meta -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

  <!-- Site Properties -->

  <!-- Use of Semantic UI CSS libraries through out the document to mantain the Website theme and work with the re adjusting of screen sizes-->
  <title>Homepage</title>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
    <!--<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/components/visibility.min.js">-->
    
    <link rel="stylesheet" href="general.css">
    <link rel="stylesheet" href="homepage.css">
    <!-- Use of Semantic UI JS libraries through out the document to mantain the Website theme and work with the re adjusting of screen sizes and component behaviours-->
    


        <script
			  src="https://code.jquery.com/jquery-3.3.1.min.js"
			  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
        crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js" integrity="sha256-t8GepnyPmw9t+foMh3mKNvcorqNHamSKtKRxxpUEgFI=" crossorigin="anonymous"></script>
    
    
  
  <script >
  $(document)
    .ready(function() {

      // fix menu when passed
      $('.masthead')
        .visibility({
          once: false,
          onBottomPassed: function() {
            $('.fixed.menu').transition('fade in');
          },
          onBottomPassedReverse: function() {
            $('.fixed.menu').transition('fade out');
          }
        })
      ;

      // create sidebar and attach to menu open
      $('.ui.sidebar')
        .sidebar('attach events', '.toc.item')
      ;

    })
  ;
  </script>
</head>
<body>
<!-- link stylesheet-->
<!--<link rel="stylesheet" href="homepage.css">-->

<!-- Following Menu -->
<div class="ui large top inverted fixed hidden menu" id= "navMenu">
  <div class="ui container">
    <a class=" item" href="homepage.php">Home</a>
    <!--<a class="item">Featured</a>-->
    <a class="item" href="footwear.php">Footwear</a>
    <a class="item" href="clothing.php">Clothing</a>
    <a class="item" href="sizing.php">Sizing</a>


    <div class="right menu">
    <div class="item">
    <a class="ui inverted basic compact icon button" href="list.php"><i class="list alternate outline icon"></i> </a>
      </div>
   
      <div class="item">
        <a class="ui inverted basic compact icon button" href="sources.php"><i class="check square icon"></i></a>
      </div>
      <div class="item">
      <a class="ui inverted red basic button" href="logout.php" role="button">Log out</a>
      </div>
    </div>
  </div>
</div>

<!-- Sidebar Menu -->
<div class="ui vertical inverted sidebar menu" id= "navMenu">
  <a class=" item" href="homepage.php">Home</a>
  <!--<a class="item">Featured</a>-->
  <a class="item" href="footwear.php">Footwear</a>
  <a class="item" href="clothing.php">Clothing</a>
  <a class="item" href="sizing.php">Sizing</a>
  
</div>




<!-- Page Contents -->
<div class="pusher">
  <div class="ui vertical masthead center aligned segment" >

    <div class="ui container " >
      <div class="ui large secondary inverted pointing menu" id= "navMenu">
        <a class="toc item">
          <i class="sidebar icon"></i>
        </a>
        <a class=" item" href="homepage.php">Home</a>
        <!--<a class="item">Featured</a>-->
        <a class="item" href="footwear.php">Footwear</a>
          <a class="item" href="clothing.php">Clothing</a>
          <a class="item" href="sizing.php">Sizing</a>
        <div class="right item" >
        <a class="ui inverted basic compact icon button" href="list.php"><i class="list alternate outline icon"></i> </a>

        <a class="ui inverted basic compact icon button" href="sources.php"><i class="check square icon"></i></a>
          <a class="ui inverted red basic button" href="logout.php" role="button">Log out</a>
        </div>
      </div>
    </div>

    <script>
    // Add active class to the current button (highlight it)
    var header = document.getElementById("navMenu");
    var buttons = header.getElementsByClassName("item");
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].addEventListener("click", function() {
      var current = document.getElementsByClassName("active");
      current[0].className = current[0].className.replace(" active", "");
      this.className += " active";
      });
    }
    </script>
   

 
 <!-- include the php on separate page-->
    <?php 
    //test session
   // $cars = array("Volvo", "BMW", "Toyota");
   // $_SESSION['test']=$cars;

    
    include("db.php");//get our database
    
    //SQL used select the footwear

    $sql = "SELECT Item.itemID, Item.itemName , Footwear.footwearID    FROM Footwear
    JOIN Item ON Item.itemID = Footwear.itemID;";
    //var_dump($sql); //used to check the SQL statement used 
    $result =query($sql);
    confirm($result);
    $footwearItems = fetch_all($result);//fetching all footwear

    //SQL used select the clothing

    $sql = "SELECT Item.itemID, Item.itemName , Clothing.clothingID    FROM Clothing
    JOIN Item ON Item.itemID = Clothing.itemID;";
    //var_dump($sql); //used to check the SQL statement used 
    $result = query($sql);
    confirm($result);
    $clothingItems = fetch_all($result);//fetching all footwear


    //items to source array
    //$items = array();
            if(isset($_POST["addToList"]))  
        {  
            $itemID = $_GET['id'];
          
            //var_dump("ITEM ID ==");
            //var_dump($itemID);
            //include("db.php");//get our database
                
            //SQL used select the footwear
            
            $sql = "SELECT * FROM Item WHERE itemID = '$itemID';";
            //var_dump($sql); //used to check the SQL statement used 
            $result = query($sql);
            confirm($result);
            $item= fetch_all($result);//fetching all footwear

              if(isset($_SESSION["itemList"]))  
              {  
                
                //('session exists');

                  //$itemListID = array_column($_SESSION["itemList"], "itemID");  
                  
                        $count = count($_SESSION["itemList"]);  
                        /*$itemList = array(  
                            'itemID'               =>     $_GET["id"] 
                            //'itemName'               =>     $_POST["hidden_name"],  
                            
                              
                        );  */
                        $itemList = $_SESSION["itemList"] ; 
                        array_push($itemList,$_GET["id"] );
                        $_SESSION["itemList"] = $itemList; 

                         
                        //$filtered_array = array_filter($array);
                        
                        //var_dump($itemList);
                    
                    
              }  
              else  
              //var_dump("Array--->"); 
              //var_dump($_SESSION["itemList"]); 
              
              {  
                //array creation
                $itemList = [];
                array_push($itemList,$_GET["id"] ); 
                //set array as session 
                $_SESSION["itemList"] = $itemList ; 
              } 
             //$_SESSION["itemList"]= $itemList ;
              
              //add delete
              //var_dump("Array--->"); 
            //var_dump($_SESSION["itemList"]); 
        } 


    
    include($page); 
  
    
    ?>
    <!--used w3 schools for guidance-->
  

  <div class="ui vertical footer segment">
    <div class="ui container">
      <div class="ui stackable inverted divided equal height stackable grid">
        <div class="three wide column">
          <h4 class="ui inverted header">About</h4>
          <div class="ui inverted link list">
            <a href="#" class="item">Sitemap</a>
            <a href="#" class="item">Contact Us</a>
            <a href="#" class="item">Religious Ceremonies</a>
            <a href="#" class="item">Gazebo Plans</a>
          </div>
        </div>
        <div class="three wide column">
          <h4 class="ui inverted header">Services</h4>
          <div class="ui inverted link list">
            <a href="#" class="item">Banana Pre-Order</a>
            <a href="#" class="item">DNA FAQ</a>
            <a href="#" class="item">How To Access</a>
            <a href="#" class="item">Favorite X-Men</a>
          </div>
        </div>
        <div class="seven wide column">
          <h4 class="ui inverted header">Footer Header</h4>
          <p style= "color: grey">Extra space for a call to action inside the footer that could help re-engage users.</p>
        </div>
      </div>
    </div>
  </div>
</div>

</body>

</html>