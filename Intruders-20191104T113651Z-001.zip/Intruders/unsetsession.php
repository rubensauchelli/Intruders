<?php
$page = "unsetsession_content.php";
include("template.php");
//var_dump($_SESSION['itemList']);
//session_destroy();
//echo "<script>window.location = 'list.php'</script>";

?>