<?php

$page = "clothing_content.php";
include("template.php");

?>