

<!-- Pending orders-->

<div class="ui container"style= "padding-top:5%"   >

<div class="ui segment">
<h2 class="ui left floated header">Pending Orders</h2>
<div class="ui clearing divider"></div>
<div class="ui divided items">

</div>
</div>




<!-- Completed orders-->


<div class="ui container"style= "padding-top:0%"   >

<div class="ui segment">
<h2 class="ui left floated header">Completed Orders</h2>
<div class="ui clearing divider"></div>
<div class="ui divided items">

<?php

//include("db.php");//get our database
    
//SQL used select the footwear




$sql_items = "SELECT Orders.orderID, Orders.customerID,Orders.itemID, Orders.size, Orders.orderDate, Item.itemName  FROM Orders
JOIN Item ON Item.itemID = Orders.itemID;";
//var_dump($sql); //used to check the SQL statement used 
$result = query($sql_items);
confirm($result);
$itemsOrdered = fetch_all($result);//fetching all customers


foreach ($itemsOrdered as $orderedItem){ // populates table on the website for every ordered item on the database
    
    $customerID = $orderedItem['customerID'];
    $sql_customers = "SELECT *  FROM Customer
    WHERE customerID = $customerID;";
    //var_dump($sql); //used to check the SQL statement used 
    $result = query($sql_customers);
    confirm($result);
    $customer = fetch_array($result);//fetching all customers

    
    echo'<div class="item">';    
         echo'<div class="image">';   
             echo'<img src="items/'.strtoupper($orderedItem['itemID']).'.jpg">';    
         echo'</div>';    
         echo'<div class="content">';    
             echo'<a class="header">';    
                 echo $orderedItem['size'].'  '.$orderedItem['itemName'];        
             echo'</a>';     
            echo'<div class="meta">';     
                    echo'<span>'.$customer['firstName'].' '.$customer['lastName'].'</span>';         
            echo'</div>';     
            echo' <div class="description">';    
                echo'<p>'.$customer['streetAddress'].'<br/>'.$customer['city'].' '.$customer['postCode'].'<br/>'.$customer['country'].'<br/>'.$customer['phoneNumber'].'</p>';         
            echo'</div>';     
            echo'<div class="extra">';     
                echo'ORDER ID: '.$orderedItem['orderID'].'   DATE:'.$orderedItem['orderDate'];          
            echo'</div>';     
        echo'</div>';     
    echo'</div>';  

}
            



?>





</div>





</div>


