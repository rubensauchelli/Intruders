<?php

$page = "footwear_content.php";
include("template.php");

?>