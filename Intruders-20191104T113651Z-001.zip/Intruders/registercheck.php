<?php

$page = "registercheck_content.php";
include("pretemplate.php");

?>