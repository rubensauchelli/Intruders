<?php

$page = "login_content.php";
include("pretemplate.php");

?>