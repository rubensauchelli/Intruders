
<div class="ui text container"  >
      <h1 class="ui inverted header" >
        Clothing
      </h1>
      
    </div>

  </div>


<?php
        
        
        
        echo'<div class="ui container" >';
        echo'<div class="ui four column doubling stackable grid container">';
        echo'<div class="ui four doubling cards">';
        

        foreach ($clothingItems as $clothingItem){ // populates table on the website for every clothing item on the database
            
            //cart preparation
            echo '<form class="card" method="post" action="clothing.php?action=add&id='.$clothingItem['itemID'].'">'; 
           
            
            
            echo '  <div class="image">';
            echo '      <img src="items/';
                            echo  strtoupper($clothingItem['itemID']);
                            echo '.jpg">';
            echo '  </div>';
            echo '  <div class="content">';
            echo '      <div class="header">';
                            echo $clothingItem['itemName'];
            echo '      </div>';
            echo '      <div class="meta">';
                            echo '<p>';
                            echo strtoupper($clothingItem['itemID']);
                            echo '</p>';
            
           
            
            //echo '';
            

            echo '       </div>';
            echo '  </div>';
                        
                        
        
            
                             echo '  <input class="ui bottom attached button" type="submit" name="addToList" value="ADD TO LIST">';
                                
                            
                            echo '  </input>';
                            
            echo '  </form>';

            
            
            
            
            
            
           

        }
        
        //unset($db);//clean up our resources 
        echo '</div>';
        echo '</div>';
        echo '</div>';
        

    ?>