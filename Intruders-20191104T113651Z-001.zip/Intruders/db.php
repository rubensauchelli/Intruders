<?php 
//THIS FILE NEEDS TO BE USED FOR MIGRATION TO MYSQL


//this will be used to connect the db

$con = mysqli_connect('localhost','root','','intruders_db');
//escape
function escape($string){
    global $con;
    return mysqli_real_escape_string($con, $string);
}
//queries
function query($query){
    global $con;
    return mysqli_query($con, $query);
}
//confirm
function confirm($result){
    global $con;
    if(!$result){
        die("QUERY FAILED". mysqli_error($con));
    }
}

//fetch
function fetch_array($result){
    global $con;
    return mysqli_fetch_array($result);
}
//fetchAll
function fetch_all($result){
    global $con;
    return mysqli_fetch_all($result,MYSQLI_ASSOC);
}


?>