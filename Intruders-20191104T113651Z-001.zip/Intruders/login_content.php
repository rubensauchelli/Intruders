





<div class="ui middle aligned center aligned grid" >

  <div class="column">
    
    <form class="ui large form" method="post" action = "logincheck.php" style="padding-top: 70%" id= "loginForm">
      <div class="ui segment" id="loginForm">
        <div class="field">
          <div class="ui left icon input" id="customInput">
            <i class="user icon"></i>
            <input type="text" name="username" placeholder="Username" required>
          </div>
        </div>
        <div class="field" >
          <div class="ui left icon input" > 
            <i class="lock icon"></i>
            <input type="password" name="password" placeholder="Password" required>
          </div>
        </div>
        <button class="ui fluid large black submit button"  id="customButton" type='submit'>Login</button>
      </div>
      <div class="ui message">
      New to us? <a href="register.php">Sign Up</a>
    </div>
      <div class="ui hidden negative message transition ">
      <i class="close icon"></i>
      <div class="header">
        Error
      </div>
      <p>The login details were incorrect
    </p>
      </div>
      
      

      <div class="ui error message"></div>

    </form>


  </div>
</div>

