
<?php 


/*USED ONLY FOR MIGRATION TO MYSQL

ob_start();
//start session
session_start();
//var_dump('session started');

//connect my database
include("db.php");
//TEST CONNECTION
//if($con){
 // echo"YES CONNECTED";
//}


*/
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Semantic CSS -->
    <!-- Used Semantic UI CSS libraries through out the document to mantain the Website theme and work with the re adjusting of screen sizes-->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
    <link rel="stylesheet" href="login.css">
    
     <!-- Optional JavaScript -->
        <!-- JQuery -->
         <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Semantic JS -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <!-- Used Semantic UI JS libraries through out the document to mantain the Website theme and work with the re adjusting of screen sizes and component behaviours-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js"></script>
        
    
    <!-- Website Title -->
    <title>Intruders</title>
  </head>
  <body>

       
        
        <main role="main">

        <?php
            include($page);
        ?>  

        </main>
        

       
    </body>

</html>