<?php

$page = "sources_content.php";
include("template.php");

?>