<div class="ui text container"  >
      <h1 class="ui inverted header" >
        Sizing
      </h1>
      <h2 style="color: #F4F4F4">Men's and women's Adidas and Nike footwear sizing </h2>
      <h4 style="color: #9B9B9B">Feel free to ask our staff to try on the same models in other colorways we may have in your size to find your perfect fit</h4>
    </div>

  </div>
  <div class="ui container" >
  <h2 class="ui inverted header" >
        Adidas
      </h2>
<table class="ui celled table">
  <thead>
    <tr><th>US</th>
    <th>UK</th>
    <th>EU</th>
    <th>CM</th>
    <th>WM</th>

  </tr></thead>
  <tbody>
    <tr>
      <td data-label="US">4</td>
      <td data-label="UK">3.5</td>
      <td data-label="EU">36</td>
      <td data-label="CM">22</td>
      <td data-label="WM">5</td>
    </tr>
    <tr>
    <td data-label="US">4.5</td>
      <td data-label="UK">4</td>
      <td data-label="EU">36.5</td>
      <td data-label="CM">22.5</td>
      <td data-label="WM">5.5</td>
    </tr>
    <tr>
    <td data-label="US">5</td>
      <td data-label="UK">4.5</td>
      <td data-label="EU">37</td>
      <td data-label="CM">23</td>
      <td data-label="WM">6</td>
    </tr>
    <td data-label="US">5.5</td>
      <td data-label="UK">5</td>
      <td data-label="EU">38</td>
      <td data-label="CM">23.5</td>
      <td data-label="WM">6.5</td>
    </tr>
    <td data-label="US">6</td>
      <td data-label="UK">5.5</td>
      <td data-label="EU">38.5</td>
      <td data-label="CM">24</td>
      <td data-label="WM">7</td>
    </tr>
    <td data-label="US">6.5</td>
      <td data-label="UK">6</td>
      <td data-label="EU">39</td>
      <td data-label="CM">24.5</td>
      <td data-label="WM">7.5</td>
    </tr>
    <td data-label="US">7</td>
      <td data-label="UK">6.5</td>
      <td data-label="EU">40</td>
      <td data-label="CM">25</td>
      <td data-label="WM">8</td>
    </tr>
    <td data-label="US">7.5</td>
      <td data-label="UK">7</td>
      <td data-label="EU">40.5</td>
      <td data-label="CM">25.5</td>
      <td data-label="WM">8.5</td>
    </tr>
    <td data-label="US">8</td>
      <td data-label="UK">7.5</td>
      <td data-label="EU">41</td>
      <td data-label="CM">26</td>
      <td data-label="WM">9</td>
    </tr>
    <td data-label="US">8.5</td>
      <td data-label="UK">8</td>
      <td data-label="EU">42</td>
      <td data-label="CM">26.5</td>
      <td data-label="WM">9.5</td>
    </tr>
    <td data-label="US">9</td>
      <td data-label="UK">8.5</td>
      <td data-label="EU">42.5</td>
      <td data-label="CM">27</td>
      <td data-label="WM">10</td>
    </tr>
    <td data-label="US">9.5</td>
      <td data-label="UK">9</td>
      <td data-label="EU">43</td>
      <td data-label="CM">27.5</td>
      <td data-label="WM">10.5</td>
    </tr>
    <td data-label="US">10</td>
      <td data-label="UK">9.5</td>
      <td data-label="EU">44</td>
      <td data-label="CM">28</td>
      <td data-label="WM">11</td>
    </tr>
    <td data-label="US">10.5</td>
      <td data-label="UK">10</td>
      <td data-label="EU">44.5</td>
      <td data-label="CM">28.5</td>
      <td data-label="WM">11.5</td>
    </tr>
    <td data-label="US">11</td>
      <td data-label="UK">10.5</td>
      <td data-label="EU">45</td>
      <td data-label="CM">29</td>
      <td data-label="WM">12</td>
    </tr>
    <td data-label="US">11.5</td>
      <td data-label="UK">11</td>
      <td data-label="EU">46</td>
      <td data-label="CM">29.5</td>
      <td data-label="WM">12.5</td>
    </tr>
    <td data-label="US">12</td>
      <td data-label="UK">11.5</td>
      <td data-label="EU">46.5</td>
      <td data-label="CM">30</td>
      <td data-label="WM">13</td>
    </tr>
    <td data-label="US">12.5</td>
      <td data-label="UK">12</td>
      <td data-label="EU">47</td>
      <td data-label="CM">30.5</td>
      <td data-label="WM">13.5</td>
    </tr>
  </tbody>
</table>
<h2 class="ui inverted header" >
        Nike
      </h2>
<table class="ui celled table">
  <thead>
    <tr><th>US</th>
    <th>UK</th>
    <th>EU</th>
    <th>CM</th>
    <th>WM</th>

  </tr></thead>
  <tbody>
  <tr>
      <td data-label="US">3.5</td>
      <td data-label="UK">2.5</td>
      <td data-label="EU">35.5</td>
      <td data-label="CM">22</td>
      <td data-label="WM">5</td>
    </tr>
    <tr>
      <td data-label="US">4</td>
      <td data-label="UK">3</td>
      <td data-label="EU">36</td>
      <td data-label="CM">22.5</td>
      <td data-label="WM">5.5</td>
    </tr>
    <tr>
    <td data-label="US">4.5</td>
      <td data-label="UK">3.5</td>
      <td data-label="EU">36.5</td>
      <td data-label="CM">23</td>
      <td data-label="WM">6</td>
    </tr>
    <tr>
    <td data-label="US">5</td>
      <td data-label="UK">4</td>
      <td data-label="EU">37.5</td>
      <td data-label="CM">23.5</td>
      <td data-label="WM">6.5</td>
    </tr>
    <td data-label="US">5.5</td>
      <td data-label="UK">4.5</td>
      <td data-label="EU">38</td>
      <td data-label="CM">24</td>
      <td data-label="WM">7</td>
    </tr>
    <td data-label="US">6</td>
      <td data-label="UK">5.5</td>
      <td data-label="EU">38.5</td>
      <td data-label="CM">24</td>
      <td data-label="WM">7.5</td>
    </tr>
    <td data-label="US">6.5</td>
      <td data-label="UK">6</td>
      <td data-label="EU">39</td>
      <td data-label="CM">24.5</td>
      <td data-label="WM">8</td>
    </tr>
    <td data-label="US">7</td>
      <td data-label="UK">6</td>
      <td data-label="EU">40</td>
      <td data-label="CM">25</td>
      <td data-label="WM">8.5</td>
    </tr>
    <td data-label="US">7.5</td>
      <td data-label="UK">6.5</td>
      <td data-label="EU">40.5</td>
      <td data-label="CM">25.5</td>
      <td data-label="WM">9</td>
    </tr>
    <td data-label="US">8</td>
      <td data-label="UK">7</td>
      <td data-label="EU">41</td>
      <td data-label="CM">26</td>
      <td data-label="WM">9.5</td>
    </tr>
    <td data-label="US">8.5</td>
      <td data-label="UK">7.5</td>
      <td data-label="EU">42</td>
      <td data-label="CM">26.5</td>
      <td data-label="WM">10</td>
    </tr>
    <td data-label="US">9</td>
      <td data-label="UK">8</td>
      <td data-label="EU">42.5</td>
      <td data-label="CM">27</td>
      <td data-label="WM">10.5</td>
    </tr>
    <td data-label="US">9.5</td>
      <td data-label="UK">8.5</td>
      <td data-label="EU">43</td>
      <td data-label="CM">27.5</td>
      <td data-label="WM">11</td>
    </tr>
    <td data-label="US">10</td>
      <td data-label="UK">9</td>
      <td data-label="EU">44</td>
      <td data-label="CM">28</td>
      <td data-label="WM">11.5</td>
    </tr>
    <td data-label="US">10.5</td>
      <td data-label="UK">9.5</td>
      <td data-label="EU">44.5</td>
      <td data-label="CM">28.5</td>
      <td data-label="WM">12</td>
    </tr>
    <td data-label="US">11</td>
      <td data-label="UK">10</td>
      <td data-label="EU">45</td>
      <td data-label="CM">29</td>
      <td data-label="WM">12.5</td>
    </tr>
    <td data-label="US">11.5</td>
      <td data-label="UK">10.5</td>
      <td data-label="EU">45.5</td>
      <td data-label="CM">29.5</td>
      <td data-label="WM">13</td>
    </tr>
    <td data-label="US">12</td>
      <td data-label="UK">11</td>
      <td data-label="EU">46</td>
      <td data-label="CM">30</td>
      <td data-label="WM">13.5</td>
    </tr>
    <td data-label="US">12.5</td>
      <td data-label="UK">11.5</td>
      <td data-label="EU">47</td>
      <td data-label="CM">30.5</td>
      <td data-label="WM">14</td>
    </tr>
  </tbody>
</table>
</div>