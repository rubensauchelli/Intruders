<?php

$page = "placeorder_content.php";
include("template.php");
    
?>