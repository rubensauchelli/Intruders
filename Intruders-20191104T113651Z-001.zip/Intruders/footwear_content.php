
<div class="ui text container"  >
      <h1 class="ui inverted header" >
        Footwear
      </h1>
      
    </div>

  </div>


<?php
        
        
        
        echo'<div class="ui container" >';
        echo'<div class="ui four column doubling stackable grid container">';
        echo'<div class="ui four doubling cards">';
        

        foreach ($footwearItems as $footwearItem){ // populates table on the website for every footwear item on the database
            
            
            //cart preparation
            echo '<form class="card" method="post" action="footwear.php?action=add&id='.$footwearItem['itemID'].'">'; 
           
            
            
            echo '  <div class="image">';
            echo '      <img src="items/';
                            echo $footwearItem['itemID'];
                            echo '.jpg">';
            echo '  </div>';
            echo '  <div class="content">';
            echo '      <div class="header">';
                            echo $footwearItem['itemName'];
            echo '      </div>';
            echo '      <div class="meta">';
                            echo '<p>';
                            echo $footwearItem['itemID'];
                            echo '</p>';
            
           
            
            //echo '';
            

            echo '       </div>';
            echo '  </div>';
                        
                        
        
            
                             echo '  <input class="ui bottom attached button" type="submit" name="addToList" value="ADD TO LIST">';
                                
                            
                            echo '  </input>';
                            
            echo '  </form>';

            
            
            
            
            
            
           

        }
        
        //unset($db);//clean up our resources 
        echo '</div>';
        echo '</div>';
        echo '</div>';
        

    ?>