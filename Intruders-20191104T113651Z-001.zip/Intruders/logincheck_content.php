
<?php
  include("db.php");

  // if the user is attempting a login, then the code will try to login them in
  if (isset($_POST["username"])){
    $username = $_POST["username"];
    $password = $_POST["password"];
    $hash = hash('sha512', $password);

    // check the username and password
    $sql = "SELECT * FROM User WHERE username = '$username' AND password = '$hash'";
    //var_dump($sql);
    $result = query($sql);
    confirm($result);
    $user = fetch_array($result);

    if (!empty($user)) {
      echo '</div>';

      // the cookie will expire when the browser window is closed
      setcookie("userID", $user["userID"], 0);
      //loads respective index
      echo "<script>window.location = 'homepage.php'</script>";
    } 
    else {
      // incorrect login, show the form again with a prompt
      
      echo '<div class="ui red message">The login details were incorrect, please try again.</div>';
      

      include("index.php");
    } 
  } else {
    // this will show the form if there hasn't been a user login attempt
    include("index.php");
  }

  // clean up our resources
  //unset($db);
?>

<script>
  $("#loginForm").validate();//add validation
</script>